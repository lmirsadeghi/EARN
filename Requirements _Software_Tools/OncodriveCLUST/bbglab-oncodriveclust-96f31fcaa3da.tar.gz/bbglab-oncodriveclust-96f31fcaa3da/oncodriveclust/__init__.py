VERSION = "0.4.1"
AUTHORS = "Barcelona Biomedical Genomics research group"
CONTACT_EMAIL = "nuria.lopez@upf.edu"
