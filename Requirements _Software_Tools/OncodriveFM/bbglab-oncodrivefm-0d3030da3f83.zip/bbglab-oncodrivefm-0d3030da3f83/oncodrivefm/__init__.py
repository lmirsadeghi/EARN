VERSION = "1.0.3"
AUTHORS = "Barcelona Biomedical Genomics research group"
CONTACT_EMAIL = "nuria.lopez@upf.edu"
